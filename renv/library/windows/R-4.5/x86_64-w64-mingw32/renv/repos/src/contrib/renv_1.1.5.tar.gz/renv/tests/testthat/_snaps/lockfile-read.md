# renv_lockfile_read gives informative error

    Code
      renv_lockfile_read(file)
    Condition
      Error:
      ! Failed to parse 'renv.lock':
      parse error: premature EOF
                                             {
                           (right here) ------^

